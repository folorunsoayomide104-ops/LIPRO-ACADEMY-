import Link from 'next/link';
import { LiproLogo } from '@/components/LiproLogo';

export function LandingFooter() {
  return (
    <footer className="px-4 pb-8 pt-12 md:pb-12 md:pt-16">
      <div className="glass mx-auto max-w-7xl rounded-2xl p-6 md:p-8">
        <div className="grid grid-cols-2 gap-6 md:grid-cols-4 md:gap-8">
          {/* Brand — full width on xs, normal on md */}
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <div className="grid h-9 w-9 place-items-center rounded-xl bg-[#0a0a0c] ring-1 ring-white/10">
                <LiproLogo className="h-5 w-5" />
              </div>
              <span className="font-bold">LIPRO ACADEMY</span>
            </Link>
            <p className="mt-3 text-xs leading-relaxed text-lipro-700/60 dark:text-lipro-200/60">
              Smarter revision for Nigerian university students. Study anywhere, anytime.
            </p>
            {/* Social links on mobile */}
            <div className="mt-4 flex gap-3 md:hidden">
              <a href="https://wa.me/2349160216396" target="_blank" rel="noopener" className="text-xs text-lipro-600 underline-offset-2 hover:underline dark:text-lipro-300">WhatsApp</a>
              <a href="https://www.tiktok.com/@lipro512" target="_blank" rel="noopener" className="text-xs text-lipro-600 underline-offset-2 hover:underline dark:text-lipro-300">TikTok</a>
            </div>
          </div>

          {[
            { title: 'Product', links: [
              { label: 'LIPRO AI', href: '/lipro-ai' },
              { label: 'CBT Engine', href: '/cbt' },
              { label: 'Pricing', href: '/#pricing' },
            ]},
            { title: 'Account', links: [
              { label: 'Sign in', href: '/login' },
              { label: 'Register', href: '/register' },
              { label: 'Wallet', href: '/wallet' },
            ]},
            { title: 'Legal', links: [
              { label: 'Privacy Policy', href: '/privacy' },
              { label: 'Terms', href: '/terms' },
              { label: 'About', href: '/about' },
            ]},
          ].map(col => (
            <div key={col.title}>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-lipro-600/80 dark:text-lipro-200/80">{col.title}</h4>
              <ul className="mt-3 space-y-2">
                {col.links.map(l => (
                  <li key={l.label}>
                    <Link href={l.href} className="text-xs text-lipro-700/70 transition-colors hover:text-lipro-600 dark:text-lipro-200/70 dark:hover:text-lipro-300 md:text-sm">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-8 border-t border-lipro-200/30 pt-5 text-center text-xs text-lipro-700/50 dark:text-lipro-200/50">
          © {new Date().getFullYear()} LIPRO ACADEMY — Your Life In Progress.
        </div>
      </div>
    </footer>
  );
}
