'use client';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sparkles, ArrowRight, Brain, BookOpen, Trophy } from 'lucide-react';

export function LandingHero() {
  return (
    <section className="relative overflow-hidden px-4 py-16 md:py-28 lg:py-32">
      <div className="mx-auto max-w-5xl text-center">

        {/* Badge */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs font-medium text-lipro-700 dark:text-lipro-200">
            <Sparkles className="h-3.5 w-3.5 flex-shrink-0" />
            <span>AI-Powered Learning for Nigerian Universities</span>
          </div>
        </motion.div>

        {/* Heading */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mt-5 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl lg:text-6xl"
        >
          Master your degree with{' '}
          <span className="bg-gradient-to-r from-lipro-500 via-fuchsia-500 to-indigo-500 bg-clip-text text-transparent">
            LIPRO AI
          </span>
        </motion.h1>

        {/* Sub */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mx-auto mt-5 max-w-2xl text-sm text-lipro-700/80 dark:text-lipro-200/70 sm:text-base md:text-lg"
        >
          From CBT exams to instant AI-generated revision guides, LIPRO Academy is the all-in-one platform built for Nigerian students who want to study smarter, not harder.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-7 flex flex-col items-center gap-3 sm:flex-row sm:justify-center"
        >
          <Link href="/register" className="w-full sm:w-auto">
            <Button size="lg" className="w-full sm:w-auto">
              Start learning free <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <Link href="/login" className="w-full sm:w-auto">
            <Button variant="outline" size="lg" className="w-full sm:w-auto">
              Sign in
            </Button>
          </Link>
        </motion.div>

        {/* Social proof pills */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.45 }}
          className="mt-6 flex flex-wrap items-center justify-center gap-2 text-xs text-lipro-600/70 dark:text-lipro-300/70"
        >
          <span className="flex items-center gap-1.5 rounded-full bg-lipro-50 dark:bg-lipro-950/40 px-3 py-1">✓ Free to start</span>
          <span className="flex items-center gap-1.5 rounded-full bg-lipro-50 dark:bg-lipro-950/40 px-3 py-1">✓ No card required</span>
          <span className="flex items-center gap-1.5 rounded-full bg-lipro-50 dark:bg-lipro-950/40 px-3 py-1">✓ 7 universities supported</span>
        </motion.div>

        {/* Feature cards */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-3"
        >
          {[
            { icon: Brain, title: 'LIPRO AI Tutor', desc: 'ChatGPT-level guidance with context from your courses, notes and past questions.' },
            { icon: BookOpen, title: 'Notes & Courses', desc: 'Structured material, organized by faculty and level, available anywhere.' },
            { icon: Trophy, title: 'CBT Engine', desc: 'Practice and timed exam modes that mimic the real university CBT experience.' },
          ].map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 * i }}
              className="card text-left"
            >
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-lipro-500/20 to-lipro-700/20 text-lipro-600 dark:text-lipro-300">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-sm font-semibold sm:text-base">{f.title}</h3>
              <p className="mt-1.5 text-xs text-lipro-700/70 dark:text-lipro-200/70 sm:text-sm">{f.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Ambient blobs */}
      <div aria-hidden className="pointer-events-none absolute -top-24 -left-24 h-64 w-64 rounded-full bg-lipro-400/20 blur-3xl" />
      <div aria-hidden className="pointer-events-none absolute -bottom-24 -right-24 h-64 w-64 rounded-full bg-fuchsia-400/20 blur-3xl" />
    </section>
  );
}
