'use client';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { LiproLogo } from '@/components/LiproLogo';
import { Menu, X } from 'lucide-react';

const LINKS = [
  { label: 'Features', href: '#features' },
  { label: 'Universities', href: '#universities' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Testimonials', href: '#testimonials' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Contact', href: '#contact' },
];

export function LandingNav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Lock body scroll when menu open
  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  return (
    <>
      <nav className={`sticky top-0 z-50 w-full transition-all duration-300 ${scrolled ? 'glass shadow-lg shadow-lipro-900/10' : 'bg-transparent'}`}>
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-6">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5" onClick={() => setOpen(false)}>
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-[#0a0a0c] ring-1 ring-white/10">
              <LiproLogo className="h-5 w-5" />
            </div>
            <span className="text-sm font-bold tracking-tight md:text-base">LIPRO ACADEMY</span>
          </Link>

          {/* Desktop links */}
          <div className="hidden items-center gap-6 text-sm font-medium text-lipro-700/80 dark:text-lipro-200/80 md:flex">
            {LINKS.map(l => (
              <a key={l.href} href={l.href} className="transition-colors hover:text-lipro-600 dark:hover:text-lipro-300">{l.label}</a>
            ))}
          </div>

          {/* Desktop CTA */}
          <div className="hidden items-center gap-2 md:flex">
            <Link href="/login"><Button variant="ghost" size="sm">Sign in</Button></Link>
            <Link href="/register"><Button size="sm">Get started</Button></Link>
          </div>

          {/* Mobile: CTA + hamburger */}
          <div className="flex items-center gap-2 md:hidden">
            <Link href="/register">
              <Button size="sm" className="h-8 px-3 text-xs">Get started</Button>
            </Link>
            <button
              onClick={() => setOpen(v => !v)}
              className="grid h-9 w-9 place-items-center rounded-xl glass transition-all"
              aria-label="Toggle menu"
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-40 md:hidden" aria-modal="true">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setOpen(false)} />
          {/* Drawer */}
          <div className="absolute right-0 top-0 h-full w-72 glass flex flex-col shadow-2xl animate-slide-down">
            <div className="flex items-center justify-between border-b border-lipro-200/30 dark:border-lipro-700/30 px-5 py-4">
              <span className="text-sm font-bold tracking-tight">Menu</span>
              <button onClick={() => setOpen(false)} className="grid h-8 w-8 place-items-center rounded-lg hover:bg-lipro-100 dark:hover:bg-lipro-900/40">
                <X className="h-4 w-4" />
              </button>
            </div>
            <nav className="flex flex-col gap-1 p-4 flex-1">
              {LINKS.map(l => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="flex items-center rounded-xl px-4 py-3 text-sm font-medium text-lipro-700 dark:text-lipro-200 hover:bg-lipro-50 dark:hover:bg-lipro-950/40 transition-colors"
                >
                  {l.label}
                </a>
              ))}
            </nav>
            <div className="border-t border-lipro-200/30 dark:border-lipro-700/30 p-4 flex flex-col gap-2">
              <Link href="/login" onClick={() => setOpen(false)}>
                <Button variant="outline" className="w-full">Sign in</Button>
              </Link>
              <Link href="/register" onClick={() => setOpen(false)}>
                <Button className="w-full">Get started free</Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
