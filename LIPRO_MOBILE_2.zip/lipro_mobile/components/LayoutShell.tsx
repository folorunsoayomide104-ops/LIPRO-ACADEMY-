'use client';
import { ReactNode } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard, BookOpen, StickyNote, Brain, Wallet as WalletIcon,
  Bell, Settings, LogOut, Menu, Home, ArrowRight, X, ChevronRight
} from 'lucide-react';
import { LiproLogo } from '@/components/LiproLogo';
import { cn } from '@/lib/utils';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

const NAV = [
  { label: 'Dashboard',       href: '/dashboard',         icon: LayoutDashboard },
  { label: 'Courses',         href: '/courses',           icon: BookOpen },
  { label: 'Notes',           href: '/notes',             icon: StickyNote },
  { label: 'CBT Engine',      href: '/cbt',               icon: Brain },
  { label: 'LIPRO AI',        href: '/lipro-ai',          icon: LiproLogo, highlight: true },
  { label: 'PDF Intelligence',href: '/pdf-intelligence',  icon: LiproLogo, highlight: true },
  { label: 'Wallet',          href: '/wallet',            icon: WalletIcon },
  { label: 'Settings',        href: '/settings',          icon: Settings },
];

// Mobile bottom nav items (most important 5)
const BOTTOM_NAV = [
  { label: 'Home',     href: '/dashboard',    icon: LayoutDashboard },
  { label: 'Courses',  href: '/courses',      icon: BookOpen },
  { label: 'AI',       href: '/lipro-ai',     icon: LiproLogo, highlight: true },
  { label: 'CBT',      href: '/cbt',          icon: Brain },
  { label: 'More',     href: null,            icon: Menu },
];

export function LayoutShell({ children, roleLabel }: { children: ReactNode; roleLabel?: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/auth/me').then(r => r.json()).then(d => {
      if (d.user?.avatarUrl) setAvatarUrl(d.user.avatarUrl);
    }).catch(() => {});
    const onAvatar = (e: Event) => setAvatarUrl((e as CustomEvent).detail || null);
    window.addEventListener('avatar-updated', onAvatar);
    return () => window.removeEventListener('avatar-updated', onAvatar);
  }, []);

  useEffect(() => {
    NAV.forEach(item => router.prefetch(item.href));
    router.prefetch('/notifications');
  }, [router]);

  // Lock body scroll when mobile sidebar open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const logout = async () => {
    await fetch('/api/auth/login', { method: 'DELETE' });
    router.push('/login');
  };

  const SidebarContent = ({ onClose }: { onClose?: () => void }) => (
    <aside className="flex h-full w-64 flex-col gap-1 p-4">
      {/* Logo */}
      <div className="mb-6 flex items-center justify-between px-2">
        <div className="flex items-center gap-2.5">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-[#0a0a0c] ring-1 ring-white/10">
            <LiproLogo className="h-5 w-5" />
          </div>
          <div>
            <div className="heading text-sm font-bold tracking-tight uppercase">LIPRO Academy</div>
            <div className="text-[10px] uppercase tracking-wider text-lipro-500">{roleLabel || 'AI Learning Platform'}</div>
          </div>
        </div>
        {onClose && (
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg hover:bg-lipro-100 dark:hover:bg-lipro-900/40 lg:hidden">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Nav items */}
      {NAV.map(item => {
        const active = pathname === item.href || pathname.startsWith(item.href + '/');
        const Icon = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={() => onClose?.()}
            className={cn(
              'group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all',
              active
                ? 'glass text-lipro-700 dark:text-white'
                : 'text-lipro-600/70 hover:bg-lipro-50 dark:text-lipro-200/70 dark:hover:bg-lipro-950/40'
            )}
          >
            {active && <span className="absolute left-0 top-1/2 h-5 w-1 -translate-y-1/2 rounded-full bg-lipro-500" aria-hidden />}
            <Icon className={cn('h-4 w-4 flex-shrink-0', active && 'text-lipro-600')} />
            <span>{item.label}</span>
            {item.highlight && <span className="ml-auto h-2 w-2 rounded-full bg-lipro-500 animate-pulse" />}
            {active && <ChevronRight className="ml-auto h-3.5 w-3.5 text-lipro-400" />}
          </Link>
        );
      })}

      {/* Footer */}
      <div className="mt-auto px-2 pt-4">
        <Link
          href="/"
          onClick={() => onClose?.()}
          className="mb-2 flex w-full items-center gap-3 rounded-xl border border-lipro-200/50 bg-lipro-50/50 px-3 py-2.5 text-sm font-medium text-lipro-700 transition-colors hover:bg-lipro-100/60 dark:border-lipro-500/20 dark:bg-lipro-950/30 dark:text-lipro-200 dark:hover:bg-lipro-950/50"
        >
          <Home className="h-4 w-4" /> Visit homepage
        </Link>
        <button
          onClick={logout}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-rose-500 transition-all hover:bg-rose-50 dark:hover:bg-rose-950/30"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>
    </aside>
  );

  return (
    <div className="flex min-h-screen">
      {/* Desktop sidebar */}
      <div className="sticky top-0 hidden h-screen w-64 flex-shrink-0 lg:block">
        <SidebarContent />
      </div>

      {/* Mobile sidebar drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute left-0 top-0 h-full glass shadow-2xl">
            <SidebarContent onClose={() => setMobileOpen(false)} />
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="sticky top-0 z-40 flex h-14 items-center justify-between gap-3 border-b border-lipro-100/60 bg-white/80 px-4 backdrop-blur-xl dark:border-lipro-500/10 dark:bg-surface-dark/80 lg:h-16">
          {/* Hamburger (mobile) */}
          <button
            className="grid h-9 w-9 place-items-center rounded-xl glass lg:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>

          {/* Mobile logo (visible only on mobile, hidden on desktop where sidebar shows) */}
          <Link href="/dashboard" className="flex items-center gap-2 lg:hidden">
            <div className="grid h-7 w-7 place-items-center rounded-lg bg-[#0a0a0c] ring-1 ring-white/10">
              <LiproLogo className="h-4 w-4" />
            </div>
            <span className="text-sm font-bold tracking-tight">LIPRO</span>
          </Link>

          {/* Right actions */}
          <div className="ml-auto flex items-center gap-2">
            <Link href="/notifications" className="grid h-9 w-9 place-items-center rounded-xl glass transition-all hover:scale-105">
              <Bell className="h-4 w-4" />
            </Link>
            <Link href="/settings" className="hidden h-9 w-9 place-items-center rounded-xl glass transition-all hover:scale-105 sm:grid">
              <Settings className="h-4 w-4" />
            </Link>
            <Link href="/settings" className="flex items-center gap-2 rounded-xl glass px-3 py-1.5">
              <div className="grid h-7 w-7 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-lipro-500 to-lipro-700 text-xs font-bold text-white flex-shrink-0">
                {avatarUrl
                  ? <img src={avatarUrl} alt="Avatar" className="h-full w-full object-cover" />
                  : 'U'
                }
              </div>
              <span className="hidden text-xs font-medium sm:block">Account</span>
            </Link>
          </div>
        </header>

        {/* Page content — extra bottom padding on mobile for bottom nav */}
        <main className="flex-1 px-3 pb-24 pt-2 sm:px-4 sm:pb-12 lg:pb-12">
          {children}
        </main>
      </div>

      {/* Mobile bottom navigation bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 flex h-16 items-stretch border-t border-lipro-100/60 bg-white/90 backdrop-blur-xl dark:border-lipro-500/10 dark:bg-surface-dark/90 lg:hidden safe-area-inset-bottom">
        {BOTTOM_NAV.map(item => {
          if (item.href === null) {
            // "More" button opens sidebar
            return (
              <button
                key="more"
                onClick={() => setMobileOpen(true)}
                className="flex flex-1 flex-col items-center justify-center gap-1 text-lipro-500/60 dark:text-lipro-400/60"
              >
                <Menu className="h-5 w-5" />
                <span className="text-[10px] font-medium">More</span>
              </button>
            );
          }
          const active = pathname === item.href || pathname.startsWith(item.href + '/');
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex flex-1 flex-col items-center justify-center gap-1 transition-colors',
                active
                  ? 'text-lipro-600 dark:text-lipro-300'
                  : 'text-lipro-500/50 dark:text-lipro-400/50 hover:text-lipro-500 dark:hover:text-lipro-300'
              )}
            >
              <div className="relative">
                <Icon className={cn('h-5 w-5 transition-transform', active && 'scale-110')} />
                {item.highlight && !active && (
                  <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-lipro-500" />
                )}
                {active && (
                  <span className="absolute -bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-lipro-500" />
                )}
              </div>
              <span className={cn('text-[10px] font-medium', active && 'font-semibold')}>{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
