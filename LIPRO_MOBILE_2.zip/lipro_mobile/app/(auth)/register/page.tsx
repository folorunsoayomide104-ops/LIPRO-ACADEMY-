'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input, Label } from '@/components/ui/input';
import { ArrowRight, Eye, EyeOff } from 'lucide-react';
import { LiproLogo } from '@/components/LiproLogo';

export default function RegisterPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agree, setAgree] = useState(false);
  const [form, setForm] = useState({
    email: '', password: '', fullName: '', matricNumber: '',
    university: '', faculty: '', department: '',
    level: '100', semester: 'First',
  });
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm({ ...form, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agree) { setError('Please accept the Privacy Policy and Terms to continue.'); return; }
    setLoading(true); setError('');
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) { setError(data?.error || 'Registration failed'); setLoading(false); return; }
    router.push('/dashboard');
  };

  return (
    <div className="flex min-h-screen items-start justify-center px-4 py-8 sm:items-center sm:py-12">
      <div className="card w-full max-w-lg">
        <div className="mb-6 flex items-center gap-2">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#0a0a0c] ring-1 ring-white/10">
            <LiproLogo className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Create your LIPRO account</h1>
            <p className="text-xs text-lipro-600/70 dark:text-lipro-200/60">Join thousands of Nigerian university students</p>
          </div>
        </div>
        <form onSubmit={submit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div><Label>Full name</Label><Input value={form.fullName} onChange={set('fullName')} required className="mt-1" autoComplete="name" /></div>
          <div><Label>Email</Label><Input type="email" value={form.email} onChange={set('email')} required className="mt-1" autoCapitalize="none" autoComplete="email" /></div>
          <div className="sm:col-span-2">
            <Label>Password</Label>
            <div className="relative mt-1">
              <Input type={showPassword ? 'text' : 'password'} value={form.password} onChange={set('password')} required minLength={8} className="pr-10" autoComplete="new-password" />
              <button type="button" onClick={() => setShowPassword(s => !s)} aria-label={showPassword ? 'Hide' : 'Show'} className="absolute right-3 top-1/2 -translate-y-1/2 text-lipro-400 hover:text-lipro-600">
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <div className="sm:col-span-2"><Label>Matric number</Label><Input value={form.matricNumber} onChange={set('matricNumber')} required className="mt-1" /></div>
          <div className="sm:col-span-2"><Label>University</Label><Input value={form.university} onChange={set('university')} placeholder="University of Lagos" required className="mt-1" /></div>
          <div><Label>Faculty</Label><Input value={form.faculty} onChange={set('faculty')} placeholder="Science" required className="mt-1" /></div>
          <div><Label>Department</Label><Input value={form.department} onChange={set('department')} placeholder="Computer Science" required className="mt-1" /></div>
          <div>
            <Label>Level</Label>
            <select className="input mt-1" value={form.level} onChange={set('level')}>
              {['100','200','300','400','500','600','Staff'].map(l => <option key={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <Label>Semester</Label>
            <select className="input mt-1" value={form.semester} onChange={set('semester')}>
              <option value="First">First</option>
              <option value="Second">Second</option>
            </select>
          </div>
          <label className="flex items-start gap-2 text-sm sm:col-span-2 cursor-pointer">
            <input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)} className="mt-0.5 h-4 w-4 accent-lipro-600 flex-shrink-0" />
            <span className="text-xs leading-relaxed text-lipro-600/80 dark:text-lipro-200/70">
              I agree to the <Link href="/privacy" className="font-medium text-lipro-600 hover:underline">Privacy Policy</Link> and <Link href="/terms" className="font-medium text-lipro-600 hover:underline">Terms of Service</Link>.
            </span>
          </label>
          {error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-xs text-rose-600 dark:bg-rose-950/30 dark:text-rose-400 sm:col-span-2">{error}</p>}
          <div className="sm:col-span-2">
            <Button type="submit" disabled={loading || !agree} className="w-full">
              {loading ? 'Creating account…' : 'Create account'} <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </form>
        <p className="mt-5 text-center text-sm text-lipro-600/70 dark:text-lipro-200/60">
          Already have an account? <Link href="/login" className="font-semibold text-lipro-600 hover:underline">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
