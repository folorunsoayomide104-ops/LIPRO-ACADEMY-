'use client';
import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input, Label } from '@/components/ui/input';
import { Mail, Lock, ArrowRight, Eye, EyeOff } from 'lucide-react';
import { LiproLogo } from '@/components/LiproLogo';

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const router = useRouter();
  const search = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [agree, setAgree] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agree) { setError('Please accept the Privacy Policy and Terms to continue.'); return; }
    setLoading(true); setError('');
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) { setError(data?.error || 'Login failed'); setLoading(false); return; }
    router.push(search.get('redirect') || '/dashboard');
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4 py-8 sm:py-12">
      {/* Card — full width on xs, capped on sm+ */}
      <div className="card w-full max-w-sm sm:max-w-md">

        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <div className="grid h-10 w-10 flex-shrink-0 place-items-center rounded-xl bg-[#0a0a0c] ring-1 ring-white/10">
            <LiproLogo className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight sm:text-xl">Welcome back</h1>
            <p className="text-xs text-lipro-600/70 dark:text-lipro-200/60">Sign in to LIPRO Academy</p>
          </div>
        </div>

        <form onSubmit={submit} className="space-y-4">
          {/* Email */}
          <div>
            <Label htmlFor="email">Email address</Label>
            <div className="relative mt-1">
              <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-lipro-400" />
              <Input
                id="email"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="pl-10"
                placeholder="you@example.com"
                autoComplete="email"
                autoCapitalize="none"
                required
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <div className="flex items-center justify-between">
              <Label htmlFor="password">Password</Label>
              <span className="text-xs text-lipro-500 cursor-pointer hover:underline">Forgot password?</span>
            </div>
            <div className="relative mt-1">
              <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-lipro-400" />
              <Input
                id="password"
                type={showPw ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="pl-10 pr-10"
                placeholder="••••••••"
                autoComplete="current-password"
                required
              />
              <button
                type="button"
                onClick={() => setShowPw(v => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-lipro-400 hover:text-lipro-600"
                aria-label={showPw ? 'Hide password' : 'Show password'}
              >
                {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          {/* Agree checkbox */}
          <label className="flex items-start gap-2.5 text-sm text-lipro-600/80 dark:text-lipro-200/70 cursor-pointer">
            <input
              type="checkbox"
              checked={agree}
              onChange={e => setAgree(e.target.checked)}
              className="mt-0.5 h-4 w-4 accent-lipro-600 flex-shrink-0"
            />
            <span className="text-xs leading-relaxed sm:text-sm">
              I agree to the{' '}
              <Link href="/privacy" className="font-medium text-lipro-600 hover:underline">Privacy Policy</Link>
              {' '}and{' '}
              <Link href="/terms" className="font-medium text-lipro-600 hover:underline">Terms of Service</Link>.
            </span>
          </label>

          {error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-xs text-rose-600 dark:bg-rose-950/30 dark:text-rose-400">{error}</p>}

          <Button type="submit" disabled={loading || !agree} className="w-full py-2.5 text-sm">
            {loading ? 'Signing in…' : 'Sign in'} <ArrowRight className="h-4 w-4" />
          </Button>
        </form>

        <p className="mt-5 text-center text-sm text-lipro-600/70 dark:text-lipro-200/60">
          New here?{' '}
          <Link href="/register" className="font-semibold text-lipro-600 hover:underline">Create a free account</Link>
        </p>

        {/* Demo accounts */}
        <details className="mt-4">
          <summary className="cursor-pointer text-xs font-medium text-lipro-500 hover:text-lipro-600 select-none">
            Demo accounts ▸
          </summary>
          <div className="mt-2 rounded-xl bg-lipro-50/50 p-3 text-xs text-lipro-700/80 dark:bg-lipro-950/30 dark:text-lipro-200/70 space-y-1">
            <p className="font-semibold">Password: <code>Password123!</code></p>
            <p>superadmin@lipro.academy</p>
            <p>admin@lipro.academy</p>
            <p>lecturer@lipro.academy</p>
            <p>student@lipro.academy</p>
          </div>
        </details>
      </div>
    </div>
  );
}
