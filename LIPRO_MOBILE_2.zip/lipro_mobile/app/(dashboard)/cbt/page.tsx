import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/auth';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StartExamButton } from '@/components/cbt/start-exam-button';
import { PdfExamCreator } from '@/components/cbt/pdf-exam-creator';
import { Brain, Clock, GraduationCap } from 'lucide-react';

export default async function CbtIndexPage() {
  const session = await getSession();
  if (!session) redirect('/login');

  const [courses, sessions, materials] = await Promise.all([
    prisma.course.findMany({
      include: { _count: { select: { questions: true } }, lecturer: { select: { fullName: true } } },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.examSession.findMany({
      where: { userId: session.userId },
      include: { course: { select: { code: true, title: true } } },
      orderBy: { startedAt: 'desc' },
      take: 10,
    }),
    prisma.material.findMany({
      where: { userId: session.userId },
      include: { _count: { select: { questions: true } } },
      orderBy: { createdAt: 'desc' },
      take: 10,
    }),
  ]);

  const docs = materials.map(m => ({
    id: m.id,
    originalName: m.originalName,
    sizeBytes: m.sizeBytes,
    questionCount: m._count.questions,
    createdAt: m.createdAt.toISOString(),
  }));

  return (
    <div className="space-y-5">
      {/* Page header */}
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 flex-shrink-0 place-items-center rounded-xl bg-gradient-to-br from-lipro-500/20 to-indigo-500/20 text-lipro-600 dark:text-lipro-300">
          <Brain className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight sm:text-2xl">CBT Engine</h1>
          <p className="text-xs text-lipro-600/70 dark:text-lipro-200/70 sm:text-sm">Practice, timed exams and document-based sessions</p>
        </div>
      </div>

      {/* Top grid: PDF exam + Recent attempts */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Exam from document</CardTitle>
            <CardDescription className="text-xs">Upload a PDF, generate questions and start a timed exam</CardDescription>
          </CardHeader>
          <CardContent>
            <PdfExamCreator materials={docs} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">Recent attempts</CardTitle>
                <CardDescription className="text-xs">Your last 10 sessions</CardDescription>
              </div>
              <Clock className="h-4 w-4 text-lipro-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {sessions.length === 0 && (
                <p className="py-4 text-center text-sm text-lipro-600/60">No attempts yet — start a session below.</p>
              )}
              {sessions.map(s => (
                <div key={s.id} className="rounded-xl p-3 glass-hover flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium">{s.course?.code ?? 'Document exam'}</div>
                    <div className="text-xs text-lipro-600/60">{new Date(s.startedAt).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</div>
                  </div>
                  <Badge tone={s.status === 'completed' ? 'green' : 'amber'} className="flex-shrink-0 text-xs">
                    {s.status === 'completed' && s.score !== null && s.totalPoints
                      ? `${Math.round((s.score / s.totalPoints) * 100)}%`
                      : 'In progress'}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Course-based sessions */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-4 w-4 text-lipro-500" />
            <div>
              <CardTitle className="text-base">Start from a course</CardTitle>
              <CardDescription className="text-xs">Pick a course and exam mode</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {courses.map(c => (
              <div key={c.id} className="rounded-xl p-3 glass-hover">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold">{c.code} · {c.title}</div>
                    <div className="text-xs text-lipro-600/60">{c._count.questions} questions · {c.lecturer.fullName}</div>
                  </div>
                  <div className="flex-shrink-0">
                    <StartExamButton courseId={c.id} />
                  </div>
                </div>
              </div>
            ))}
            {courses.length === 0 && (
              <p className="py-4 text-center text-sm text-lipro-600/60">No courses with questions available yet.</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
