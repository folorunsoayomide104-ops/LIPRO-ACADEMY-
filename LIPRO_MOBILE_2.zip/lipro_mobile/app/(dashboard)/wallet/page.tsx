import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/auth';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { WalletFundButton } from '@/components/dashboard/wallet-fund-button';
import { formatCurrency } from '@/lib/utils';
import { Wallet, CreditCard, ArrowUpRight, ArrowDownLeft } from 'lucide-react';

export default async function WalletPage() {
  const session = await getSession();
  if (!session) redirect('/login');
  const [me, txns] = await Promise.all([
    prisma.user.findUnique({
      where: { id: session.userId },
      select: { walletBalance: true, subscriptionTier: true, subscriptionExpiry: true },
    }),
    prisma.walletTxn.findMany({
      where: { userId: session.userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    }),
  ]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 flex-shrink-0 place-items-center rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-700/20 text-amber-600 dark:text-amber-300">
          <Wallet className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight sm:text-2xl">Wallet</h1>
          <p className="text-xs text-lipro-600/70 dark:text-lipro-200/70 sm:text-sm">Manage your LIPRO balance and subscription</p>
        </div>
      </div>

      {/* Balance + Subscription */}
      <div className="grid gap-3 sm:grid-cols-2 sm:gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Current balance</CardDescription>
            <CardTitle className="text-2xl sm:text-3xl">{formatCurrency(me?.walletBalance || 0)}</CardTitle>
          </CardHeader>
          <CardContent>
            <WalletFundButton />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-lipro-400" />
              <CardDescription className="text-xs">Subscription</CardDescription>
            </div>
            <CardTitle className="text-base sm:text-lg">{me?.subscriptionTier || 'FREE'}</CardTitle>
          </CardHeader>
          <CardContent>
            {me?.subscriptionExpiry
              ? <p className="mb-2 text-xs text-lipro-600/60">Active until {new Date(me.subscriptionExpiry).toLocaleDateString()}</p>
              : <p className="mb-2 text-xs text-lipro-600/60">No active subscription</p>
            }
            <a href="/subscription" className="text-xs font-semibold text-lipro-600 hover:underline dark:text-lipro-300">Change plan →</a>
          </CardContent>
        </Card>
      </div>

      {/* Transactions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Transaction history</CardTitle>
          <CardDescription className="text-xs">Your recent wallet activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {txns.length === 0 && (
              <p className="py-6 text-center text-sm text-lipro-600/60">No transactions yet.</p>
            )}
            {txns.map(t => (
              <div key={t.id} className="flex items-center justify-between gap-3 rounded-xl p-3 glass-hover">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`grid h-8 w-8 flex-shrink-0 place-items-center rounded-lg ${t.type === 'CREDIT' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400' : 'bg-rose-100 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400'}`}>
                    {t.type === 'CREDIT' ? <ArrowDownLeft className="h-3.5 w-3.5" /> : <ArrowUpRight className="h-3.5 w-3.5" />}
                  </div>
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium">{t.type} {t.reference ? `· ${t.reference}` : ''}</div>
                    <div className="text-xs text-lipro-600/60">{new Date(t.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</div>
                  </div>
                </div>
                <Badge tone={t.type === 'CREDIT' ? 'green' : 'rose'} className="flex-shrink-0 text-xs font-bold">
                  {t.type === 'CREDIT' ? '+' : '-'}{formatCurrency(t.amount)}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
