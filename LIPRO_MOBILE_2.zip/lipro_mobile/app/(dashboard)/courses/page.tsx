import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/auth';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { CourseForm } from '@/components/dashboard/course-form';
import { BookOpen, ArrowRight } from 'lucide-react';

export default async function CoursesPage() {
  const session = await getSession();
  if (!session) redirect('/login');
  const canCreate = ['LECTURER','ADMIN','SUPER_ADMIN'].includes(session.role);

  const courses = await prisma.course.findMany({
    include: { _count: { select: { notes: true, questions: true } }, lecturer: { select: { fullName: true } } },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 flex-shrink-0 place-items-center rounded-xl bg-gradient-to-br from-lipro-500/20 to-lipro-700/20 text-lipro-600 dark:text-lipro-300">
            <BookOpen className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight sm:text-2xl">Courses</h1>
            <p className="text-xs text-lipro-600/70 dark:text-lipro-200/70 sm:text-sm">Browse and manage academy courses</p>
          </div>
        </div>
      </div>

      {canCreate && <CourseForm />}

      {/* Course grid — 1 col mobile, 2 col sm, 3 col lg */}
      <div className="grid gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-3">
        {courses.length === 0 && (
          <p className="col-span-full py-8 text-center text-sm text-lipro-600/60">No courses yet.</p>
        )}
        {courses.map(c => (
          <Link key={c.id} href={`/courses/${c.id}`} className="group block">
            <Card className="h-full transition-all group-active:scale-[0.98]">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between gap-2">
                  <Badge tone="purple" className="text-xs">{c.code}</Badge>
                  <span className="text-xs text-lipro-600/60">L{c.level} · {c.semester}</span>
                </div>
                <CardTitle className="mt-2 line-clamp-2 text-sm sm:text-base">{c.title}</CardTitle>
                <CardDescription className="line-clamp-2 text-xs">{c.description}</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center justify-between">
                  <span className="truncate text-xs text-lipro-600/60">{c.lecturer.fullName}</span>
                  <div className="flex flex-shrink-0 items-center gap-1.5">
                    <Badge tone="indigo" className="text-xs">{c._count.notes}</Badge>
                    <Badge tone="amber" className="text-xs">{c._count.questions}Q</Badge>
                    <ArrowRight className="h-3.5 w-3.5 text-lipro-400 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
